# FromHereToThere

External Libraries
* JQuery
* Bootstrap
* Vue
* Vue2Leaflet (to render map)
* Leaflet Routing Machine (to get routes on the map)
* Popper (needed for bootstrap tooltips)
* Bootstrap Icons
* Nominatim (Open Street Map) - API used to search for Geolocation based on name